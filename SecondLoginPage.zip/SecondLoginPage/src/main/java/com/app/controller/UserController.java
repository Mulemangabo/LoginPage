package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.app.entity.User;
import com.app.repo.UserRepo;

@Controller
public class UserController {
	
	@Autowired(required = true)
	private UserRepo userRepository;
	
	@GetMapping("/")
	public String login(Model model) {
		
		User user = new User();
		model.addAttribute("user",user);
		
		return "logPage"; 
	}
	
	@PostMapping("/userLogin")
	public String loginUser(@ModelAttribute("user") User user, Model model) {

		String userID = user.getUserID();
		Optional<User> userData = userRepository.findById(userID);
		
		if(user.getUserID().equalsIgnoreCase(userData.get().getUserID())) {
			
			if(user.getPassword().equals(userData.get().getPassword())) {
	            
				List<User> userList = userRepository.findAll();
				model.addAttribute("userList",userList);
				
				if(userData.get().getAdmin().equalsIgnoreCase("yes")) {
					return "adminPage";
				} else {
					return "employeePage";					
				}
				
			} else {
				return "errorPage";
			}
		} else {
			return "errorPage";
		}	
	}
	
    @GetMapping("/addEmployee")
    public String addEmployeePage(Model model) {
        model.addAttribute("newUser", new User());
        
        return "addEmployeePage";
    }
    
	@PostMapping("/userLogin/addEmployee")
	public String addEmployee(@ModelAttribute("user") User newUser) {
		newUser.setAdmin("no");
		userRepository.save(newUser);
		
		return "newEmployeePage";
	}
	
    @GetMapping("/goBack")
    public String goBackBtn(Model model) {     
        return "redirect:/";
    }
}
