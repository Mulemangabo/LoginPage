package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.app.entity.User;
import com.app.repo.UserRepo;

@Controller
public class UserController {
	
	@Autowired(required = true)
	private UserRepo userRepository;
	
	@GetMapping("/")
	public String login(Model model) {
		
		User user = new User();
		model.addAttribute("user",user);
		
		return "logPage"; 
	}
	
	@PostMapping("/userLogin")
	public String loginUser(@ModelAttribute("user") User user, Model model) {

		String userID = user.getUserID();
		Optional<User> userData = userRepository.findById(userID);
		
		if(user.getUserID().equalsIgnoreCase(userData.get().getUserID())) {
			
			if(user.getPassword().equals(userData.get().getPassword())) {
	            
				List<User> userList = userRepository.findAll();
				model.addAttribute("userList",userList);
				
				if(userData.get().getAdmin().equalsIgnoreCase("yes")) {
					return "adminPage";
				} else {
					return "employeePage";					
				}
				
			} else {
				model.addAttribute("errorMessage", "Incorrect password");
				return "errorPage";
			}
		} else {
			model.addAttribute("errorMessage", "User not found");
			return "errorPage";
		}	
	}
	
    @GetMapping("/addEmployee")
    public String addEmployeePage(Model model) {
        model.addAttribute("newUser", new User());
        
        return "addEmployeePage";
    }
    
	@PostMapping("/userLogin/addEmployee")
	public String addEmployee(@ModelAttribute("user") User newUser) {
		newUser.setAdmin("no");
		userRepository.save(newUser);
		
		return "newEmployeePage";
	}
	
    @GetMapping("/goBack")
    public String goBackBtn(Model model) {     
        return "redirect:/";
    }
    
    @GetMapping("/removeEmployee")
    public String removeEmployeePage(Model model) {
        model.addAttribute("user2", new User());
        
        return "removeEmployeePage";
    }
    
	@PostMapping("/userLogin/removeEmployee")
	public String removeEmployee(@ModelAttribute("user") User user, Model model) {
		String userID = user.getUserID();
		Optional<User> userData = userRepository.findById(userID);
		if(userData.isPresent()) {
			userRepository.deleteById(userData.get().getUserID());
			return "employeeRemoved";			
		} else {
			model.addAttribute("errorMessage", "User not found");
			return "errorPage";		
		}
	}
	
    @GetMapping("/promoteEmployee")
    public String promoteEmployeePage(Model model) {
        model.addAttribute("user3", new User());
        
        return "promoteEmployee";
    }
    
	@PostMapping("/userLogin/promoteEmployee")
	public String promoteEmployee(@ModelAttribute("user") User user, Model model) {
		String userID = user.getUserID();
		Optional<User> userData = userRepository.findById(userID);
		if(userData.isPresent()) {
			User userUpdate = userData.get();
			userUpdate.setAdmin("Yes");
			userRepository.save(userUpdate);
			return "employeePromotted";
		} else {
			model.addAttribute("errorMessage", "User not found");
			return "errorPage";	
		}

	}
	
    @GetMapping("/profileEmployee")
    public String profileEmployeePage(Model model) {
    	User newUser = new User();
        model.addAttribute("user4", newUser);
       
        return "employeeProfileID";
    }
    
	@PostMapping("/userLogin/profileEmployee")
	public String profileEmployee(@ModelAttribute("user") User newUser, Model model) {
		String userID = newUser.getUserID();
		Optional<User> userData = userRepository.findById(userID);
		String isAdmin = "";
		
	    if (userData.isPresent()) {	
	    	User userDetails = userData.get();
	        model.addAttribute("userDetails", userDetails);
	        if(userDetails.getAdmin().equalsIgnoreCase("Yes")) {
	        	isAdmin = "Administrator";
	        	model.addAttribute("isAdmin", isAdmin);
	        } else {
	        	isAdmin = "Employee";
	        	model.addAttribute("isAdmin", isAdmin);
	        }
	    } else {
	        model.addAttribute("errorMessage", "User not found");
	        return "errorPage";
	    }

		return "profileEmployee";
	}
}
